
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numeros = new int[10];
		numeros[0] = 56;
		System.out.println(numeros.length);
	}

	
	public Event[] getEventsWithTags(Event[] events, Tags[] tags) {
		
		Event[] tagedEvents;
		
		for(Event e: events) {
			
			if(containsAllTags(e, tags))
		}
		
		return events;
	}
	
	public boolean containsAllTags(Event e, Tags[] tags) {
		
		boolean contains = true;
		
		for(Tags t: tags) {
			
			
		}
		
	}
}
