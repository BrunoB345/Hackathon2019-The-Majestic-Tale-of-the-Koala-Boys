package com.example.asus.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class EventActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        String name = getIntent().getStringExtra("name");
        String date = getIntent().getStringExtra("date");
        String hour = getIntent().getStringExtra("hour");
        String duration = getIntent().getStringExtra("duration");
        String description = getIntent().getStringExtra("description");
        String location = getIntent().getStringExtra("location");
        String link = getIntent().getStringExtra("link");

        int id = getResources().getIdentifier("textView", "id", getPackageName());
        ((TextView) findViewById(id)).setText(name);
        id = getResources().getIdentifier("textView2", "id", getPackageName());
        ((TextView) findViewById(id)).setText(date);
        id = getResources().getIdentifier("textView3", "id", getPackageName());
        ((TextView) findViewById(id)).setText(hour);
        id = getResources().getIdentifier("textView7", "id", getPackageName());
        ((TextView) findViewById(id)).setText(duration);
        id = getResources().getIdentifier("textView6", "id", getPackageName());
        ((TextView) findViewById(id)).setText(location);
        id = getResources().getIdentifier("textView4", "id", getPackageName());
        ((TextView) findViewById(id)).setText(description);
        id = getResources().getIdentifier("textView5", "id", getPackageName());
        ((TextView) findViewById(id)).setText(link);
    }
}
