package com.example.asus.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.LinkedList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

public class MainActivity extends AppCompatActivity {

    List<Event> events;
    SortedMap<Integer, List<Event>> durEvents;
    SortedMap<String, List<Event>> catEvents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        events = new LinkedList<>();
        durEvents = new TreeMap<>();
        catEvents = new TreeMap<>();
        createTest();

        LinearLayout ll = findViewById()

        for(int i = events.size()-1; i>=0; i--){
            Button btn = new Button(this);
            btn.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT ));
            btn.setId(i);
            btn.setText(events.get(i).getName());
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    action(view);
                }
            });
        }
    }



    public void action(View view){
        int i = view.getId();
        Intent intent = new Intent(this, EventActivity.class);
        intent.putExtra("name", events.get(i).getName());
        intent.putExtra("date", (events.get(i).getDate()));
        intent.putExtra("hour", (events.get(i).getHour()));
        intent.putExtra("duration", Integer.toString(events.get(i).getDuration()));
        intent.putExtra("description", events.get(i).getDescription());
        intent.putExtra("location", events.get(i).getLocation());
        intent.putExtra("link", events.get(i).getLink());
        startActivity(new Intent(this, EventActivity.class));
        finish();
    }

    private void createTest()  {
        events.add(new Event("Cinema", "24/05/2019", "15:30", 34, "Povoa Varzim", "Espero que a descrição funcione", "pic", "www.ezpz.pt" ));
        events.add(new Event("Parque", "30/07/2019", "17:30", 90, "Setubal", "Mesma descrição do costume", "pic", "www.wannawin.pt" ));
    }

}

